import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Vector;

/**
 * Created by root on 21.06.17.
 */
public class Main {

    static int numberOfSortedEl;
    static final int speed = 75;
    static final int maxElem = 65;
    static final int minRange = 0;
    static final int maxRange = 1000;
    static final int height = 600;
    static final int width = 400;
    static JFrame mainWindow = new JFrame();
    static JPanel visualizePanel = new JPanel();
    static JPanel secVisPanel = new JPanel();
    static JPanel firstVisPanel = new JPanel();
    static JPanel secondWorkPanel = new JPanel();
    static JPanel thirdWorkPanel = new JPanel();
    static JPanel fourWorkPanel = new JPanel();
    static JPanel fiveWorkPanel = new JPanel();
    static JPanel sixWorkPanel = new JPanel();
    static JPanel workPanel = new JPanel();
    static JPanel upperPanel = new JPanel();
    static JTextField numbOfElement = new JTextField(2);
    static JTextField[] ourArray = new JTextField[maxElem];
    static JProgressBar[] sortedEl = new JProgressBar[maxElem];
    static int[] sortedArray = new int[maxElem];
    static JButton sortButt = new JButton("BubbleSort");
    static JButton shakerSortButt = new JButton("ShakerSort");
    static JButton quickSortButt = new JButton("QuickSort");
    static JButton stupidSortButt = new JButton("StupidSort");
    static JButton anotherSortButt = new JButton("Sort");
    static JComboBox<String> sortBox = new JComboBox<String>();
    static JButton randomButt = new JButton("random");
    static JButton getButt = new JButton("get");



    public static void main(String[] args){

            mainWindow.setSize(height,width);
            mainWindow.setTitle("Shaker Sort Visualizer");

            mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            mainWindow.setMaximumSize(new Dimension(height,width));
              mainWindow.setMinimumSize(new Dimension(height,width));
            mainWindow.setResizable(true);

           mainWindow.setLayout(new BorderLayout());
           workPanel.setLayout(new GridLayout());
           workPanel.setBackground(Color.LIGHT_GRAY);
           visualizePanel.setBackground(Color.black);



            sortBox.addItem("MergeSort");
            sortBox.addItem("ShellSort");
            sortBox.addItem("SelectionSort");

            anotherSortButt.addActionListener(new AnotherSortButtonActionListener());
            stupidSortButt.addActionListener(new StupidSortButtonActionListener());
            sortButt.addActionListener(new SortButtonActionListener());
            quickSortButt.addActionListener(new QuickSortButtonActionListener());
            shakerSortButt.addActionListener(new ShakerSortButtonActionListener());

            getButt.addActionListener(new GetElButtonActionListener());
            randomButt.addActionListener(new RandomButtonActionListener());
            JLabel enterNumbOfEl = new JLabel(" Please enter number of elements: ");


            workPanel.add(getButt);
            workPanel.add(randomButt);
            workPanel.add(stupidSortButt);
            workPanel.add(sortButt);
            workPanel.add(shakerSortButt);
            workPanel.add(quickSortButt);

        for (int i = 0;i<maxElem;++i){
            ourArray[i] = new JTextField(3);
            sortedEl[i] = new JProgressBar();
            sortedEl[i].setMinimum(minRange);
            sortedEl[i].setMaximum(maxRange);
            sortedEl[i].setValue(minRange);
            sortedEl[i].setOrientation(JProgressBar.VERTICAL);

            secVisPanel.add(sortedEl[i]);
        }
        visualizePanel.setLayout(new BoxLayout(visualizePanel,BoxLayout.PAGE_AXIS));
        visualizePanel.add(secVisPanel);

        JLabel enterArrEl = new JLabel(" If you dont want random data, please enter elements: ");
        firstVisPanel.setLayout(new BorderLayout());
        secondWorkPanel.setLayout(new BorderLayout());
        thirdWorkPanel.setLayout(new BorderLayout());
        fourWorkPanel.setLayout(new BorderLayout());
        fiveWorkPanel.setLayout(new FlowLayout());
        sixWorkPanel.setLayout(new BorderLayout());
        sixWorkPanel.add(fiveWorkPanel);
        fourWorkPanel.add(sixWorkPanel,BorderLayout.CENTER);
        thirdWorkPanel.add(fourWorkPanel,BorderLayout.CENTER);
        secondWorkPanel.add(thirdWorkPanel,BorderLayout.CENTER);
        firstVisPanel.add(secondWorkPanel,BorderLayout.CENTER);

        for (int i = 0;i<maxElem;++i)
            fiveWorkPanel.add(ourArray[i]);

        thirdWorkPanel.add(enterNumbOfEl,BorderLayout.NORTH);
        fourWorkPanel.add(numbOfElement,BorderLayout.NORTH);
        sixWorkPanel.add(enterArrEl,BorderLayout.NORTH);
        visualizePanel.add(firstVisPanel,BorderLayout.CENTER);


        JLabel upper = new JLabel("          visualization: ");
        upperPanel.setLayout(new GridLayout());
        upperPanel.setBackground(Color.LIGHT_GRAY);
        upperPanel.add(sortBox);
        upperPanel.add(upper);
        upperPanel.add(anotherSortButt);
        mainWindow.add(visualizePanel,BorderLayout.CENTER);
           mainWindow.add(workPanel,BorderLayout.SOUTH);
           mainWindow.add(upperPanel,BorderLayout.NORTH);
        mainWindow.setVisible(true);

    }

    public static class GetElButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            Integer numb = maxElem,el = 0;
            for (int i = 0;i<maxElem;++i)
                sortedEl[i].setValue(minRange);
            try {
                numb = Integer.valueOf(numbOfElement.getText());
            }catch (NumberFormatException e) {
                numbOfElement.setText("Неверный формат строки");
                numb=0;
            }
            if (numb>maxElem) {
                numb = maxElem;
                numbOfElement.setText(Integer.toString(maxElem));
            }
            numberOfSortedEl = numb;

            for (Integer i = 0;i<numb;++i){
                sortedArray[i] = 0;
                try {
                    el = Integer.valueOf(ourArray[i].getText());
                }catch (NumberFormatException e) {
                    numbOfElement.setText("Неверный формат элементов");
                    return;
                }
                if (el>maxRange) {
                    el = maxRange;
                    ourArray[i].setText(Integer.toString(maxRange));
                }
                sortedArray[i] = el;
            }

            for (Integer i = 0;i<numb;++i){
                sortedEl[i].setValue(sortedArray[i]);

            }


    }}

    public static void move(Vector<Integer> result){


        Thread myThready = new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (this) {
                   lock();
                    int k = 0;
                    int flag = 1;
                    Integer j = 0;

                    for (Integer i : result) {
                        if (flag%2==0){
                            ++flag;
                        try {
                            Thread.sleep(speed);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        sortedEl[j].setForeground(Color.green);
                        try {
                            Thread.sleep(speed);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        sortedEl[i].setForeground(Color.green);
                        try {
                            Thread.sleep(speed);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        k = sortedArray[j];

                        sortedArray[j] = sortedArray[i];
                        try {
                            Thread.sleep(speed);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        sortedArray[i] = k;
                        sortedEl[j].setValue(sortedArray[j]);
                        sortedEl[i].setValue(sortedArray[i]);
                        ourArray[j].setText(Integer.toString(sortedArray[j]));
                        ourArray[i].setText(Integer.toString(sortedArray[i]));

                        sortedEl[j].setForeground(Color.blue);
                        try {
                            Thread.sleep(speed);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        sortedEl[i].setForeground(Color.blue);
                    } else {j = i;
                            ++flag;}}
                }
                for (int i = 0; i < maxElem; ++i){
                    sortedEl[i].setForeground(Color.RED);
                try {
                    Thread.sleep(speed/10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }}

                for (int i = 0; i < maxElem; ++i){
                    sortedEl[i].setForeground(Color.cyan);
                try {
                    Thread.sleep(speed/10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }}
                for (int i = 0; i < maxElem; ++i){
                    sortedEl[i].setForeground(Color.lightGray);
                try {
                    Thread.sleep(speed/10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }}
                unlock();
            }
        }); myThready.start();


    }

    private static void lock(){
        anotherSortButt.setEnabled(false);
        sortButt.setEnabled(false);
        shakerSortButt.setEnabled(false);
        quickSortButt.setEnabled(false);
        stupidSortButt.setEnabled(false);
        getButt.setEnabled(false);
        randomButt.setEnabled(false);
        for (int i = 0;i<maxElem;++i)
            ourArray[i].setEnabled(false);

    }

    private static void unlock(){
        anotherSortButt.setEnabled(true);
        sortButt.setEnabled(true);
        shakerSortButt.setEnabled(true);
        quickSortButt.setEnabled(true);
        stupidSortButt.setEnabled(true);
        getButt.setEnabled(true);
        randomButt.setEnabled(true);
        for (int i = 0;i<maxElem;++i)
            ourArray[i].setEnabled(true);

    }


    public static void moveNotChoiceSort(Vector<Integer> result){



        Thread mySecondThready = new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (this) {
                   lock();
                    int k = 0;
                    int flag = 1;
                    Integer j = 0;

                    for (Integer i : result) {
                        if (flag%2==0){
                            ++flag;
                            try {
                                Thread.sleep(speed);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            sortedEl[i].setForeground(Color.green);
                            try {
                                Thread.sleep(speed);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }


                            sortedArray[i] = j;
                            sortedEl[i].setValue(j);
                            ourArray[i].setText(Integer.toString(j));

                            try {
                                Thread.sleep(speed);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            sortedEl[i].setForeground(Color.blue);
                            try {
                                Thread.sleep(speed);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                        } else {j = i;
                            ++flag;}}
                }
                for (int i = 0; i < maxElem; ++i){
                    sortedEl[i].setForeground(Color.RED);
                    try {
                        Thread.sleep(speed/10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }}

                for (int i = 0; i < maxElem; ++i){
                    sortedEl[i].setForeground(Color.cyan);
                    try {
                        Thread.sleep(speed/10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }}
                for (int i = 0; i < maxElem; ++i){
                    sortedEl[i].setForeground(Color.lightGray);
                    try {
                        Thread.sleep(speed/10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }}
               unlock();

            }

        }); mySecondThready.start();


    }


    public static class SortButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            int[] safeArr = new int[maxElem];
            for (int i = 0;i<maxElem;++i)
                safeArr[i] = sortedArray[i];
            BubbleSort bubSort = new BubbleSort(numberOfSortedEl, safeArr);
            Vector<Integer> result;
            Integer k = 0;
            result = bubSort.sort();
            move(result);

        }
    }

    public static class ShakerSortButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            int[] safeArr = new int[maxElem];
            for (int i = 0;i<maxElem;++i)
                safeArr[i] = sortedArray[i];
            ShakerSort shakeSort = new ShakerSort(numberOfSortedEl,safeArr);
            Vector<Integer> result;
            result = shakeSort.sort();
            move(result);

        }
    }

    public static class QuickSortButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            int[] safeArr = new int[maxElem];
            for (int i = 0;i<maxElem;++i)
                safeArr[i] = sortedArray[i];
            QuickSort quickSortt = new QuickSort(numberOfSortedEl,safeArr);
            Vector<Integer> result;
            result = quickSortt.sort();
            move(result);

        }
    }

    public static class StupidSortButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            int[] safeArr = new int[maxElem];
            for (int i = 0;i<maxElem;++i)
                safeArr[i] = sortedArray[i];
            StupidSort stupSort = new StupidSort(numberOfSortedEl,safeArr);
            Vector<Integer> result;
            result = stupSort.sort();
            move(result);
        }
    }

    public static class AnotherSortButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            int[] safeArr = new int[maxElem];
            for (int i = 0;i<maxElem;++i)
                safeArr[i] = sortedArray[i];

            Vector<Integer> result;

            String choiceSort = (String) sortBox.getSelectedItem();
            switch (choiceSort) {
                case "MergeSort":
                    MergeSort merge = new MergeSort(numberOfSortedEl, safeArr);
                    result = merge.sort();
                    moveNotChoiceSort(result);
                    break;
                case "ShellSort":
                    ShellSort shell = new ShellSort(numberOfSortedEl,safeArr);
                    result = shell.sort();
                    moveNotChoiceSort(result);
                    break;
                case  "SelectionSort":
                    SelectionSort sel = new SelectionSort(numberOfSortedEl,safeArr);
                    result = sel.sort();
                    move(result);
                    break;
            }
        }
    }


    public static class RandomButtonActionListener implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent actionEvent) {

            Random random = new Random();
            Integer numb = maxElem;

            for (int i = 0;i<maxElem;++i){
                ourArray[i].setText("");
                sortedEl[i].setValue(minRange);
            }

            try {
                numb = Integer.valueOf(numbOfElement.getText());
            }catch (NumberFormatException e) {
                numbOfElement.setText("Неверный формат строки");
                numb=0;
            }
            if (numb>maxElem) {
                numb = maxElem;
                numbOfElement.setText(Integer.toString(maxElem));
            }
            numberOfSortedEl = numb;
            Integer sch = 0;
            for (Integer i = 0;i<numb;++i){
                sch = random.nextInt(maxRange);
                sortedEl[i].setValue(sch);
                sortedArray[i] = sch;
                ourArray[i].setText(sch.toString());
            }
        }
    }

}
